﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Net;
using System.Net.Http;
using System.Text.RegularExpressions;
using System.Threading.Tasks;
using System.Linq;
using System.Threading;

class ProxyScraper
{
    private static readonly HttpClient httpClient = new HttpClient();
    private static readonly List<string> ProxySources = new List<string>
    {
        "https://free-proxy-list.net/",
        "https://www.sslproxies.org/",
        "https://www.us-proxy.org/",
        "https://proxy-list.download/HTTP",
        "https://www.proxynova.com/proxy-server-list/",
        "https://spys.one/en/http-proxy-list/",
        "https://hidemy.name/en/proxy-list/?type=hs",
        "https://www.proxy-list.download/api/v1/get?type=http",
        "https://raw.githubusercontent.com/TheSpeedX/SOCKS-List/master/http.txt",
        "https://raw.githubusercontent.com/ShiftyTR/Proxy-List/master/http.txt",
        "https://raw.githubusercontent.com/clarketm/proxy-list/master/proxy-list-raw.txt",
        "https://proxy-daily.com/",
        "https://www.proxy-list.download/",
        "https://www.my-proxy.com/free-proxy-list.html",
        "https://www.freeproxy.world/?type=http",
        "https://api.proxyscrape.com/?request=displayproxies&proxytype=http&timeout=1000",
        "https://openproxy.space/list/http",
        "https://www.proxyscan.io/download?type=http",
        "https://www.proxydocker.com/en/proxylist/type/http",
        "https://premproxy.com/list/",
        "https://multiproxy.org/txt_all/proxy.txt",
        "https://rootjazz.com/proxies/proxies.txt",
        "https://proxydb.net/",
        "https://proxylist.geonode.com/api/proxy-list?protocols=http",
        "https://raw.githubusercontent.com/opsxcq/proxy-list/master/list.txt",
        "https://checkerproxy.net/api/archive/latest?type=http",
        "https://proxylist.fatezero.org/proxy.list",
        "https://raw.githubusercontent.com/jetkai/proxy-list/main/online-proxies/txt/proxies-http.txt"
    };

    public static async Task Main()
    {
        while (true)
        {
            Console.WriteLine("\n1. Найти прокси\n2. Проверить прокси\n3. Отфильтровать быстрые прокси\n4. Создатель\n5. Инструкция\n6. Дискорд\n7. Выход");
            string choice = Console.ReadLine();

            switch (choice)
            {
                case "1":
                    await FindProxies();
                    break;
                case "2":
                    CheckProxies();
                    break;
                case "3":
                    FilterFastProxies();
                    break;
                case "4":
                    Console.WriteLine("Создано by sosulacka");
                    break;
                case "5":
                    Console.WriteLine("Чтобы сгенерировать прокси напиши в командной строке 1 и нажми ENTER после этого зайди на рабочий стол и нажми F5");
                    break;
                case "6":
                    Console.WriteLine("Мой дискорд @sosulacka");
                    break;
                case "7":
                    return;
                default:
                    Console.WriteLine("Неверный выбор!");
                    break;
            }
        }
    }

    private static async Task FindProxies()
    {
        Console.WriteLine("Получаем список HTTP прокси...");
        List<string> proxies = (await Task.WhenAll(ProxySources.Select(GetProxies))).SelectMany(p => p).Distinct().Take(10000).ToList();

        if (!proxies.Any())
        {
            Console.WriteLine("Не удалось найти прокси.");
            return;
        }

        SaveProxies(proxies, "proxies.txt");
        Console.WriteLine($"Найдено {proxies.Count} прокси. Сохранено на рабочем столе.");
    }

    private static async Task<List<string>> GetProxies(string url)
    {
        List<string> proxyList = new List<string>();
        try
        {
            httpClient.DefaultRequestHeaders.Add("User-Agent", "Mozilla/5.0");
            HttpResponseMessage response = await httpClient.GetAsync(url);
            string content = await response.Content.ReadAsStringAsync();
            Regex regex = new Regex(@"(\d+\.\d+\.\d+\.\d+):(\d+)");
            MatchCollection matches = regex.Matches(content);
            proxyList.AddRange(matches.Select(match => match.Value));
        }
        catch (Exception ex)
        {
            Console.WriteLine($"Ошибка получения прокси с {url}: {ex.Message}");
        }
        return proxyList;
    }

    private static void SaveProxies(List<string> proxies, string fileName)
    {
        string desktopPath = Environment.GetFolderPath(Environment.SpecialFolder.Desktop);
        string directoryPath = Path.Combine(desktopPath, "ProxyList");
        string filePath = Path.Combine(directoryPath, fileName);

        if (!Directory.Exists(directoryPath))
        {
            Directory.CreateDirectory(directoryPath);
        }

        File.WriteAllLines(filePath, proxies);
    }

    private static void CheckProxies()
    {
        string desktopPath = Environment.GetFolderPath(Environment.SpecialFolder.Desktop);
        string directoryPath = Path.Combine(desktopPath, "ProxyList");
        string filePath = Path.Combine(directoryPath, "proxies.txt");

        if (!File.Exists(filePath))
        {
            Console.WriteLine("Файл с прокси не найден. Сначала найдите прокси.");
            return;
        }

        List<string> proxies = File.ReadAllLines(filePath).ToList();
        List<string> workingProxies = proxies.Where(IsProxyWorking).ToList();

        SaveProxies(workingProxies, "working_proxies.txt");
        Console.WriteLine("Проверка завершена. Рабочие прокси сохранены.");
    }

    private static bool IsProxyWorking(string proxy)
    {
        try
        {
            string[] parts = proxy.Split(':');
            if (parts.Length != 2 || !int.TryParse(parts[1], out int port)) return false;

            using (WebClient client = new WebClient())
            {
                client.Proxy = new WebProxy(parts[0], port);
                client.DownloadString("http://www.google.com");
            }
            return true;
        }
        catch
        {
            return false;
        }
    }

    private static void FilterFastProxies()
    {
        Console.WriteLine("Фильтрация быстрых прокси...");
    }
}
