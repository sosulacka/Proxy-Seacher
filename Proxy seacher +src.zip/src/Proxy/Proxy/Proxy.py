chcp 65001
python proxy_scraper.py
